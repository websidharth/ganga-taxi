# ShotMail - Digital Marketing Tools Suite

A fully static, SEO-optimized marketing website and tools suite built with **Next.js 14 (App Router)**, **TypeScript**, **Tailwind CSS**, and **shadcn/ui-style components**.

This project provides a collection of useful tools for developers and marketers, leveraging client-side technologies like WebAssembly (FFmpeg) to ensure fast and private processing directly in the browser.

## 🚀 Features

### Email Tools
- **Email Editor**: Interactive email template builder.
- **Send Test**: Utility to send test emails.

### Image & Media Tools
- **Image Compressor**: Optimize images for web use.
- **Image Converter**: Convert between different image formats.
- **Image Resizer**: Resize images to specific dimensions.
- **GIF Tools**: Create and manipulate GIF files (powered by FFmpeg).
- **Metadata Stripper**: Remove EXIF and metadata from images for privacy.

### Design & Brand Tools
- **Palette Generator**: Extract color palettes from images.
- **Logo Extractor**: Extract logos from websites.
- **Favicon Generator**: Generate favicons for websites.

### Utilities
- **HTML to PDF**: Convert HTML content to PDF documents.
- **QR Code Generator**: Create customizable QR codes.

## 🛠 Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: Shadcn UI (Radix UI + Tailwind)
- **Core Libraries**:
  - `@ffmpeg/ffmpeg`: Client-side video/audio processing.
  - `jspdf` & `html2canvas`: PDF generation.
  - `react-easy-crop`: Image manipulation.
  - `nodemailer`: Email transport.

## 📦 Getting Started

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or yarn

### Installation

```bash
npm install
```

### Development

Start the development server on port 3000:

```bash
npm run dev
```

Visit `http://localhost:3000` to see the application.

## 🏗 Building for Production

This project is configured for **Static Export** (`output: "export"`).

```bash
npm run build
```

The output will be generated in the `out/` directory, ready to be hosted on any static hosting service (Vercel, Netlify, GitHub Pages, AWS S3, etc.).

## 🔧 Configuration

### Environment Variables

Create a `.env.local` file in the root directory to configure environment variables:

```env
NEXT_PUBLIC_APP_NAME="ShotMail"
NEXT_PUBLIC_MAIN_DOMAIN_URL="http://localhost:3000"
NEXT_PUBLIC_API_CLIENT_ID="your-client-id"
```

## 📂 Project Structure

```
app/
├── tools/              # Individual tool pages
│   ├── email-editor/   # Email builder tool
│   ├── gif-tools/      # GIF processing tools
│   ├── image-*/        # Image manipulation tools
│   └── ...
├── api/                # API Routes (Note: API routes may limited in static export)
components/
├── common/             # Reusable shared components
├── features/           # Feature-specific components
└── ui/                 # UI Library components (Buttons, Inputs, etc.)
lib/
├── utils.ts            # Utility functions
└── image-processing.ts # Core image processing logic
```

## 📝 Notes
- **Static Export**: Since this uses `output: "export"`, standard Next.js API routes may not function in the built production environment unless hosted on a platform that supports hybrid rendering or using middleware/functions.
- **Assets**: Replace placeholder images in `public/images/` to match your branding.
