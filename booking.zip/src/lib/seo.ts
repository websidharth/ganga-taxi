export const site = {
  name: "ShotMail",
  title: "ShotMail — Modern Digital Agency",
  description:
    "ShotMail helps service businesses grow with fast websites, conversion-focused design, and measurable Email marketing.",
  url: "https://example.com",
  ogImage: "/images/og.png",
  twitterHandle: "@ShotMail",
  phone: "+1 (555) xxx-xxxx",
  email: "hello@shotmail.test",
  address: "100 Market Street, Suite 10, San Francisco, CA",
};

export const absoluteUrl = (path: string) => {
  const base = site.url.replace(/\/$/, "");
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${base}${p}`;
};
